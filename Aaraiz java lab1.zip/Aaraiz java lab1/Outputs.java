class Outputs{

public static void main(String[] args){
   System.out.println ("///////////////////////////");
   System.out.println ("    student points    ==");
   System.out.println ("///////////////////////////");
   System.out.println ("Lab    Bonus   Total");
   System.out.println ("---    -----    ----");
   System.out.println ("30      9       40" );
   System.out.println ("50      8       49" );
   System.out.print   ("55      10      51" );
}

}
 