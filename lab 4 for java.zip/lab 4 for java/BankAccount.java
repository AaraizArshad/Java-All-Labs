class BankAccount {
    private double balance;
    private int accountNumber;
    
    // Parameterized constructor
    BankAccount(int accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }
    
    // Method to deposit money
    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited " + amount + " into account " + accountNumber);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }
    
    // Method to withdraw money
    void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawn " + amount + " from account " + accountNumber);
        } else {
            System.out.println("Insufficient balance or invalid amount in account " + accountNumber);
        }
    }
    
    // Method to check balance
    void checkBalance() {
        System.out.println("Account " + accountNumber + " balance: " + balance);
    }
    
    public static void main(String[] args) {
        // Creating objects using the parameterized constructor
        BankAccount acc1 = new BankAccount(101, 1000);
        BankAccount acc2 = new BankAccount(102, 500);
        
        // Depositing money
        acc1.deposit(500);
        acc2.deposit(1500);
        
        // Checking balance
        acc1.checkBalance();
        acc2.checkBalance();
        
        // Withdrawing money
        acc1.withdraw(500);
        acc1.checkBalance();
        acc2.withdraw(3000);
    }
}
