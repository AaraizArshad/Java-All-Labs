class Circle {
    double radius;
    String color;
    
    Circle() {
        this.radius = 0;
        this.color = "";
    }
    
    void calculateArea() {
        double area = Math.PI * radius * radius;
        System.out.println("The area of the circle with radius " + radius + " is: " + area);
    }
    
    public static void main(String[] args) {
        // Creating objects using the default constructor
        Circle red_circle = new Circle();
        Circle green_circle = new Circle();
        
        // Initializing instance variables using dot operator
        red_circle.radius = 5;  // Assigning radius for red circle
        red_circle.color = "Red";
        
        green_circle.radius = 7;  // Assigning radius for green circle
        green_circle.color = "Green";
        
        // Printing radius of both circles
        System.out.println("Red Circle Radius: " + red_circle.radius);
        System.out.println("Green Circle Radius: " + green_circle.radius);
        
        // Calculating and printing the area of both circles
        red_circle.calculateArea();
        green_circle.calculateArea();
    }
}
