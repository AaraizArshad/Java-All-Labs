class Circle1 {
    double radius;
    String color;
    
    // Parameterized constructor
    Circle1(double radius, String color) {
        this.radius = radius;
        this.color = color;
    }
    
    // Method that returns the area
    double calculateArea() {
        return Math.PI * radius * radius;
    }
    
    public static void main(String[] args) {
        // Creating objects using the parameterized constructor
        Circle1 red_circle1 = new Circle1(5, "Red");
        Circle1 green_circle1 = new Circle1(7, "Green");
        
        // Printing radius of both circles
        System.out.println("Red Circle1 Radius: " + red_circle1.radius);
        System.out.println("Green Circle1 Radius: " + green_circle1.radius);
        
        // Calculating and printing the area of both circles
        System.out.println("The area of the red circle1 is: " + red_circle1.calculateArea());
        System.out.println("The area of the green circle1 is: " + green_circle1.calculateArea());
    }
}
