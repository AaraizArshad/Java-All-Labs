class Employee {
    private String name;
    private int yearOfJoining;
    private String address;

    // Parameterized constructor
    Employee(String name, int yearOfJoining, String address) {
        this.name = name;
        this.yearOfJoining = yearOfJoining;
        this.address = address;
    }

    // Method to display employee details
    void displayEmployee() {
        System.out.println(name + "\t" + yearOfJoining + "\t" + address);
    }

    public static void main(String[] args) {
        // Creating employee objects
        Employee emp1 = new Employee("Robert", 1994, "WallsStreat");
        Employee emp2 = new Employee("Sam", 2000, "WallsStreat");
        Employee emp3 = new Employee("John", 1999, "WallsStreat");
        
        // Displaying the header
        System.out.println("Name\tYear_of_Joining\tAddress");
        
        // Displaying employee details
        emp1.displayEmployee();
        emp2.displayEmployee();
        emp3.displayEmployee();
    }
}
