class Matrix {
    private int rows;
    private int cols;
    private int[][] matx;

    // Constructor to initialize rows, columns, and matrix
    Matrix(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        this.matx = new int[rows][cols];
    }

    // Method to display matrix
    void get_matrix() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print(matx[i][j] + " ");
            }
            System.out.println();
        }
    }

    // Method to set a specific element in the matrix
    void set_element(int row, int col, int value) {
        if (row >= 0 && row < rows && col >= 0 && col < cols) {
            matx[row][col] = value;
        } else {
            System.out.println("Invalid index!");
        }
    }

    public static void main(String[] args) {
        // Creating matrices
        Matrix matrix1 = new Matrix(4, 3);
        Matrix matrix2 = new Matrix(3, 3);
        
        // Initializing matrix1
        int value = 1;
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 3; j++) {
                matrix1.set_element(i, j, value++);
            }
        }
        
        // Initializing matrix2
        value = 1;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                matrix2.set_element(i, j, value++);
            }
        }
        
        // Updating matrix1 at row 1, column 2 with 3
        matrix1.set_element(1, 2, 3);
        
        // Displaying both matrices
        System.out.println("Matrix 1:");
        matrix1.get_matrix();
        
        System.out.println("Matrix 2:");
        matrix2.get_matrix();
    }
}
