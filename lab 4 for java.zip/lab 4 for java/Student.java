class Student {
    private int id;
    private String name;
    private double[] grades;

    // Parameterized constructor
    Student(int id, String name, double[] grades) {
        this.id = id;
        this.name = name;
        this.grades = grades;
    }

    // Method to calculate and display average grade
    void display_average_grade() {
        double sum = 0;
        for (double grade : grades) {
            sum += grade;
        }
        double average = sum / grades.length;
        System.out.println("Average Grade of " + name + " (ID: " + id + "): " + average);
    }

    // Method to calculate percentage for each grade
    double[] calc_percentage() {
        double[] percentages = new double[grades.length];
        for (int i = 0; i < grades.length; i++) {
            percentages[i] = (grades[i] / 200) * 100;
        }
        return percentages;
    }

    // Method to concatenate id and name
    String concat_id_name() {
        return id + "_" + name;
    }

    public static void main(String[] args) {
        double[] grades1 = {180, 190, 175, 160, 185};
        double[] grades2 = {170, 165, 180, 175, 190};
        
        // Creating student objects
        Student student1 = new Student(101, "Alice", grades1);
        Student student2 = new Student(102, "Bob", grades2);
        
        // Displaying average grades
        student1.display_average_grade();
        student2.display_average_grade();
        
        // Calculating and displaying percentages
        System.out.println("Percentages of " + student1.name + ":");
        for (double percent : student1.calc_percentage()) {
            System.out.print(percent + "% ");
        }
        System.out.println();
        
        System.out.println("Percentages of " + student2.name + ":");
        for (double percent : student2.calc_percentage()) {
            System.out.print(percent + "% ");
        }
        System.out.println();
        
        // Concatenating and displaying ID and Name
        System.out.println("Concatenated ID and Name for " + student1.name + ": " + student1.concat_id_name());
        System.out.println("Concatenated ID and Name for " + student2.name + ": " + student2.concat_id_name());
    }
}
